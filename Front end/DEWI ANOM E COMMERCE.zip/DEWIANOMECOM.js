//carousel slide

document.addEventListener('DOMContentLoaded', function () {
    const slides = document.querySelectorAll('.bg img'); // select class
    let counter = 0;

    setInterval(() => {
        // Hide the current slide
        slides[counter].classList.remove('active'); //karena .active di remove otomatis kan tiddak ada jadi hilang

        // Increment the counter and wrap around if necessary
        counter = (counter + 1) % slides.length;

        // Show the next slide
        slides[counter].classList.add('active');    //ketika di tambah active kamu bisa bikin specifier di css
    }, 5000);
});