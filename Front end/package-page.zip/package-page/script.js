let items_Picture = document.querySelectorAll('.item .item_Picture');
let items_Desc = document.querySelectorAll('.item .info_Container');

//Initial slide(jgn diubah, kecuali ada perubahan di isi konten)
let active = 0;
let batas_atas = 5;
let batas_bawah = 0;

//Function slideshow carousel
function loadShow() {
    //Buat kasih effect gambar + desc nya
    items_Picture.forEach(item => {
        item.style.transform = 'none';
        item.style.opacity = 0;
        item.style.zIndex = -1;
        item.style.filter = 'blur(5px)';
    });

    items_Desc.forEach(item => {
        item.style.transform = 'none';
        item.style.opacity = 0;
        item.style.zIndex = -1;
        item.style.filter = 'blur(5px)';
    });

    //Tampilan slide active(img sm desc)
    items_Picture[active].style.opacity = 1;
    items_Picture[active].style.zIndex = 1;
    items_Picture[active].style.filter = 'none';

    items_Desc[active].style.opacity = 1;
    items_Desc[active].style.zIndex = 1;
    items_Desc[active].style.filter = 'none';

    //Tampilan slide Prev & Next dari slide active
    const prevIndex = (active === batas_bawah) ? batas_atas : active - 1;
    const nextIndex = (active === batas_atas) ? batas_bawah : active + 1;

    items_Picture[prevIndex].style.transform = 'translateX(-90%) scale(0.8) perspective(16px) rotateY(1deg)';
    items_Picture[prevIndex].style.opacity = 0.6;
    items_Picture[prevIndex].style.zIndex = -2;
    items_Picture[prevIndex].style.filter = 'blur(5px)';

    items_Picture[nextIndex].style.transform = 'translateX(90%) scale(0.8) perspective(16px) rotateY(-1deg)';
    items_Picture[nextIndex].style.opacity = 0.6;
    items_Picture[nextIndex].style.zIndex = -2;
    items_Picture[nextIndex].style.filter = 'blur(5px)';
}

loadShow();

// Button Next-Prev
let nextBtn = document.getElementById('next');
let prevBtn = document.getElementById('prev');

//If sudah melebihi batas atas(slide terakhir + 1), pindah ke slide awal dari batas.
nextBtn.onclick = function () {
    active = (active === batas_atas) ? batas_bawah : active + 1;
    loadShow();
};

//If sudah melebihi batas bawah(slide awal - 1), pindah ke slide akhir dari batas.
prevBtn.onclick = function () {
    active = (active === batas_bawah) ? batas_atas : active - 1;
    loadShow();
};

/*
Total slide ada 15;
Paket River Tubing = 6 slide
Paket Adventure    = 5 slide
Paket Edukasi      = 4 slide
*/
let button1 = document.getElementById('river_Tubing');
let button2 = document.getElementById('adventure');
let button3 = document.getElementById('edukasi');

//Untuk nentuin batas atas + batas bawah tiap paket
button1.onclick = function () {
    active = 0;
    batas_atas = 5;
    batas_bawah = 0;
    loadShow();
};

button2.onclick = function () {
    active = 6;
    batas_atas = 10;
    batas_bawah = 6;
    loadShow();
};

button3.onclick = function () {
    active = 11;
    batas_atas = 14;
    batas_bawah = 11;
    loadShow();
};