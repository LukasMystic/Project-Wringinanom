//event listener for button
document.addEventListener('DOMContentLoaded', function() {
    var pageTitle = document.title; // Get the title of the webpage
    
    var buttons = document.querySelectorAll('.btn.nav');
    
    buttons.forEach(function(button) {
        // Extract button text content and remove leading/trailing whitespace
        var buttonText = button.textContent.trim();
        
        // Compare page title with button text content
        if (buttonText === pageTitle) {
            button.classList.add('active'); // Add active class to button whose text matches page title
        }

    });
});


//responsive nav-bar
function showSidebar(){
    const sidebar = document.querySelector('.sidebar')
    sidebar.style.display = 'flex'
}

function hideSidebar(){
    const sidebar = document.querySelector('.sidebar')
    sidebar.style.display = 'none'
}


//carousel slide
document.addEventListener('DOMContentLoaded', function () {
    const slides = document.querySelectorAll('.bg img'); // select class
    let counter = 0;

    setInterval(() => {
        // Hide the current slide
        slides[counter].classList.remove('active'); //karena .active di remove otomatis kan tiddak ada jadi hilang

        // Increment the counter and wrap around if necessary
        counter = (counter + 1) % slides.length;

        // Show the next slide
        slides[counter].classList.add('active');    //ketika di tambah active kamu bisa bikin specifier di css
    }, 3000);
});



