const content = document.getElementById('content');
const scrollbar = document.createElement('div');
scrollbar.id = 'scrollbar';
scrollbar.innerHTML = '<div id="thumb"></div><div id="indicator"></div>';
content.appendChild(scrollbar);

const thumb = document.getElementById('thumb');
const indicator = document.getElementById('indicator');

content.addEventListener('scroll', () => {
  const scrollTop = content.scrollTop;
  const scrollHeight = content.scrollHeight;
  const clientHeight = content.clientHeight;
  const scrollRatio = scrollTop / (scrollHeight - clientHeight);
  const indicatorTop = scrollRatio * (clientHeight - 20); // 20 is the indicator's height
  indicator.style.top = indicatorTop + 'px';
});
